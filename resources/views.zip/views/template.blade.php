<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>{{ config('app.name') }} : @yield('title')</title>
  </head>
  <body>
    <header>
      <nav>
        <ul>
          <li><a href="{{ url('/') }}">Accueil</a></li>
        </ul>
      </nav>
    </header>
    @yield('content')
    <footer>
    </footer>
  </body>
</html>
