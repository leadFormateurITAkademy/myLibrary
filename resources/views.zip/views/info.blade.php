@extends('template')
@section('title', 'Information')
@section('content')
  <h1>Information</h1>
@endsection
